/**
 * 
 */
package coverage.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import coverage.graph.DFGraph;
import coverage.graph.Graph;
import coverage.graph.GraphUtil;
import coverage.graph.InvalidGraphException;
import coverage.graph.Node;
import coverage.graph.Path;
import coverage.graph.Variable;

/**
 * @author wuzhi
 * 
 * Modified by Nan Li
 * Date: Feb, 2009
 *
 */
public class DFGraphCoverage_old extends HttpServlet {

	
	static DFGraph dfg;
	static String defs;
	static String uses;
	static String warning;
	
	//for applet
	static List<Path> appletPaths;
	static String title;
	
	
	
	public void doGet (HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{
		doPost(request, response);
	}
	
	public void doPost (HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException
	{
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Data Flow Graph Coverage</title>");
        out.println("</head>");
        out.println("<body bgcolor=\"#DDEEDD\">");
        out.println("<p align=\"center\"><b><font size=\"5\">Data Flow Graph Coverage Web Application</font></b></p>\n");
        
        String action =request.getParameter("action");
        if(action ==null ||action.equalsIgnoreCase("New Graph"))
        {
        	//redirect to GraphCoverage
        	dfg=null;
        	defs=null;
        	uses=null;
        	warning=null;
        	title=null;
        	RequestDispatcher dispatcher=request.getRequestDispatcher("GraphCoverage");
        	dispatcher.forward(request, response);
        }else if (action.equalsIgnoreCase("Data Flow Coverage"))
        {
        	HttpSession hs=request.getSession();
    		Graph g=(Graph)hs.getAttribute("graph");    		
    		dfg=g.createDFGraph();    		
        	out.println(printForm());
        }else if(action.equalsIgnoreCase("DU Paths"))
        {   
        	title="DU Paths";
        	dfg.removeVariables();
        	String table="";
        	if(readDefUse(request))  
        		table=getCoverage(0);
        	String result="";
        	if(warning!=null)
        		result=warning+"<b>"+title+"for all variables are:</b><br>\n"+table;
        	else
        		result="<b>"+title+" for all variables are:</b><br>\n"+table;
        	
        	out.println(printForm());
        	out.println(printResult(result));
              	
        }else if(action.equalsIgnoreCase("All Def Coverage"))
        {
        	title="All Def Coverage";
        	dfg.removeVariables();
        	String table="";
        	if(readDefUse(request))  
        		table=getCoverage(1);
        	String result="";
        	if(warning!=null)
        		result=warning+"<b>"+title+"for all variables are:</b><br>\n"+table;
        	else
        		result="<b>"+title+" for all variables are:</b><br>\n"+table;
        	
        	out.println(printForm());
        	out.println(printResult(result));
        	        	        	
        }else if(action.equalsIgnoreCase("All Use Coverage"))
        {
        	title="All Use Coverage";
        	dfg.removeVariables();
        	readDefUse(request);  
        	String table="";
        	if(readDefUse(request))  
        		table=getCoverage(2);
        	String result="";
        	if(warning!=null)
        		result=warning+"<b>"+title+"for all variables are:</b><br>\n"+table;
        	else
        		result="<b>"+title+" for all variables are:</b><br>\n"+table;
        	
        	out.println(printForm());
        	out.println(printResult(result));
        }else if (action.equalsIgnoreCase("All DU Path Coverage"))
        {
        	title="All DU Path Coverage";
        	dfg.removeVariables();
        	String table="";
        	if(readDefUse(request))      
        		table=getCoverage(3);
        	String result="";
        	if(warning!=null)
        		result=warning+"<b>"+title+"for all variables are:</b><br>\n"+table;
        	else
        		result="<b>"+title+" for all variables are:</b><br>\n"+table;
        	
        	out.println(printForm());
        	out.println(printResult(result));
        }else if (action.equalsIgnoreCase("Reset"))
        {
        	//reset the global variables
        	dfg.removeVariables();
        	defs=null;
        	uses=null;
        	warning=null;
        	title=null;
        	out.println(printForm());
        }
        
        out.println("<p style=\"font-size:80%;font-family:monospace\">\n");
        out.println("Companion software\n");
        out.println("<br>to <i>Introduction to Software Testing</i>, Ammann and Offutt.\n");
        out.println("<br>Implementation by Wuzhi Xu and Nan Li.\n");
        out.println("<br>&copy; 2007-2009, all rights reserved.</font></p>\n");
        out.println("</body>");
        out.println("</html>");
	}

	private boolean readDefUse(HttpServletRequest request) 
	{		
		defs=request.getParameter("defs");
		uses=request.getParameter("uses");
		try			
		{
			GraphUtil.readDefUse(defs, uses, dfg);
			return true;
		}catch (InvalidInputException e)
    	{
    		warning=printWarning(e);
    	}
		
		return false;
	}
	
	private String printWarning(Exception e)
	{
		String warning=""
			+"<font face=\"Garamond\">The input graph is invalid because:<br>\n"
			+"&nbsp;&nbsp;<font color=red><b>"+e.getMessage()
			+"\n Cannot to generate a set of test paths to satisfy the coverage</b></font></font><br>\n";
		
		return warning;
	}
	
	private String getCoverage(int type)
	{
		String table="<table cellSpacing=0 cellPadding=0 width=\"100%\" bgColor=#eeffee border=1>" +
				"<tr><th>Variable</th><th>"+title+"</th></tr>\n";
    	Iterator<Variable> vars=dfg.getVariableIterator();
    	appletPaths =new ArrayList<Path>();
    	
    	while(vars.hasNext())
    	{
    		List<Path> paths=null;
    		Variable v=vars.next();
    		try {
				switch (type)
				{
					case 0://du paths
						paths=new ArrayList<Path>();
						Iterator<Path> it=v.getDuPath();
						while(it.hasNext())
						{
							paths.add(it.next());
						}
						break;
					case 1://all def
						paths=dfg.findAllDef(v);
						break;
					case 2://all use
						paths=dfg.findAllUse(v);
						break;
					case 3://all du path
						paths=dfg.findAllDUPath(v);
						break;											
				}
				
				if(paths!=null)
				{
					table+=printVarPaths(v, paths);
					appletPaths.addAll(paths);
				}
			} catch (InvalidGraphException e) {
				if(warning==null || warning.equals(""))
					warning=printWarning(e);
				else
					warning+=printWarning(e);
			}	
    	}
    	
    	table+="</table>";
    	return table;
	}
	
	private String printVarPaths(Variable var, List<Path> paths)
	{		
		String result="<tr><td>"+var.getName()+"</td><td>";
		
		for(int i=0;i<paths.size();i++)		
			result+=paths.get(i).toString()+"<br>\n";
			
		result+="</td></tr>\n";
		return result;		
	}
	
	private String printResult(String msg)
	{
		String result="<table border=\"0\" width=\"100%\" cellspacing=\"0\" cellpadding=\"0\">\n"
		+"  <tr><td width=\"50%\"  valign=\"top\">"+msg+"</td>\n"
		+"    <td width=\"50%\" valign=\"top\">" 
		+"<font face=\"Garamond\">Node color: <font color=gray>Initial Node</font>,\n"
		+"<font color=black>Ending Node</font>, \n"
		+"<font color=blue>Passed Node</font>, \n"
		+"<font color=red>Unpassed Node</font></font><br> \n"
		+"<table border=1 cellspacing=0 cellpadding=0 bgcolor=\"#EEFFEE\">\n"
		+"  <tr><td>  <applet code=\"coverage.applet.GraphApplet\"\n"
		+"            archive=\"lib/graph.jar,lib/jung.jar,lib/colt.jar,lib/commons-collections.jar\"\n"
		+"            width=\"500\" height=\"500\">\n";
		
		if(appletPaths!=null)
		{
			result+="            <param name=\"path\" value=\""+GraphUtil.outputPath(appletPaths)+"\">\n"
				+"            <param name=\"title\" value=\""+title+"\">\n";
		}
		
		result+="            <param name=\"variables\" value=\""+GraphUtil.outputVariables(dfg)+"\">\n " 
		+" <param name=\"graph\" value=\""+GraphUtil.outputGraph(dfg)+"\">\n"
		
		+"    </applet></td></tr></table></td></tr>\n"
		+"</table>\n";
		
		return result;

	}
	
	private String printForm()
	{
		String form=""
			+"<FORM action=DFGraphCoverage method=post> \n"
			+"<TABLE cellSpacing=0 cellPadding=0 width=\"100%\" bgColor=#eeffee border=1>  \n"
			+"  <TBODY><TR><TD width=\"50%\">  \n"
			+"      <TABLE border=0> \n"
			+"        <TBODY>" 
			+"				<TR><TD><FONT face=Garamond>Please enter your <font color=\"green\"><b>defs</b></font> in the text box below."
			+"             Put one variable and all defs for the variable in one line, separated by spaces.  "
			+"             Put the variable name at the beginning of line.(e.g.:  x 1 2) </FONT>"
			+"				</TD></TR> \n"
			+"        <TR align=center><TD><TEXTAREA name=\"defs\" cols=30 rows=5>\n";
		if(defs!=null)
			form+=defs;
		form+="</TEXTAREA></TD></TR></TBODY></TABLE></TD> \n"
			+"    <TD width=\"50%\" vAlign=top> \n"
			+"      <TABLE border=0> \n"
			+"        <TBODY><TR><TD><FONT face=Garamond>Please enter your <font color=\"green\"><b>uses</b></font> in the text box below. Put one variable and  \n"
			+"                     all uses for the variable in one line, separated by spaces. Put the variable name at the \n"
			+"                      beginning of line. (e.g.:  x 3 4 2,3)</FONT></TD></TR> \n"
			+"        <TR align=center><TD><P><TEXTAREA name=\"uses\" cols=30 rows=5>\n";
		if(uses!=null)
			form+=uses;
		form+="</TEXTAREA> \n"
			+"            </P>  </TD></TR></TBODY></TABLE>      </TD></TR> </TBODY></TABLE>\n"
			+" <table width=\"100%\">" 
			+"		<tr><td></tr> <tr><td></tr>"
			+"		<tr><td></tr> <tr><td></tr>"
			+"		<TR><TD align =right width = \"15%\">Test Requirments: </td><td width=\"85%\">" 
			+"		<input type=submit name=\"action\" value=\"Du Paths\"> " 
			+"		&nbsp;<input type=submit name=\"action\" value=\"Du Pairs\">"
			+"		&nbsp;<input type=submit name=\"action\" value=\"Def Paths\"> " 
			+"		&nbsp;<input type=submit name=\"action\" value=\"Def Pairs\"> " 
			+"		</td></tr>\n"
			+"		<tr><td></tr> <tr><td></tr>"
			+"    <tr><td align=right width = \"15%\">Test Paths: </td> <td width=\"85%\">" 
			+" 	<INPUT type=submit value=\"All Def Coverage\" name=\"action\"> \n"
			+"    &nbsp;<input type=submit value=\"All Use Coverage\" name=\"action\"> " 
			+"		&nbsp;<INPUT type=submit value=\"All DU Path Coverage\" name=\"action\"> " 
			+"		</td></tr>\n"   
			+"		<tr><td></tr> <tr><td></tr>"
			+"    <tr><td align=right width = \"15%\"d >Others: </td><td width=\"85%\">" 
			+"  	<INPUT type=submit value=\"New Graph\" name=\"action\">\n"  
			+"		&nbsp;<INPUT type=submit name=\"action\" value=\"Reset\"> " 
			+"		 </TD></TR></tbody></table> \n"
			+"</FORM> \n";
		
		return form;
	}
}
