package coverage.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import com.gargoylesoftware.htmlunit.*;
import com.gargoylesoftware.htmlunit.html.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class GraphCoverageTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		final WebClient webClient = new WebClient();
		WebRequest request = null;
		 try {
			request = new WebRequest( new URL("http://localhost:8080/CoverageWebApplication/coverage/GraphCoverage" ), HttpMethod.POST);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		HtmlPage page = null;
		try {
			page = webClient.getPage(request);
		} catch (FailingHttpStatusCodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		HtmlForm form = page.getFormByName("graphCoverageForm");
		assertEquals("graphCoverageForm", form.getNameAttribute());
		 
		final HtmlSubmitInput buttonNodes = form.getInputByValue("Nodes");
		assertEquals("action", buttonNodes.getNameAttribute());
		
		final HtmlSubmitInput buttonEdges = form.getInputByValue("Edges");
		
		final HtmlSubmitInput buttonEdgePairs = form.getInputByValue("Edge-Pair");
		
		final HtmlSubmitInput buttonSimplePaths = form.getInputByValue("Simple Paths");
		
		final HtmlSubmitInput buttonPrimePaths = form.getInputByValue("Prime Paths");
		
		final HtmlSubmitInput buttonNodeCoverage = form.getInputByValue("Node Coverage");
		
		final HtmlSubmitInput buttonEdgeCoverage = form.getInputByValue("Edge Coverage");
		
		final HtmlSubmitInput buttonEdgePairCoverage = form.getInputByValue("Edge-Pair Coverage");
		
		final HtmlSubmitInput buttonPrimePathCoverage = form.getInputByValue("Prime Path Coverage");
		
		final HtmlSubmitInput buttonNewGraph = form.getInputByValue("New Graph");
		
		final HtmlSubmitInput buttonDataFlowCoverage = form.getInputByValue("Data Flow Coverage");
		final HtmlSubmitInput buttonLogicCoverage = form.getInputByValue("Logic Coverage");
		final HtmlSubmitInput buttonMinimalMUMCUTCoverage = form.getInputByValue("Minimal-MUMCUT Coverage");
		
		final HtmlTextArea textAreaEdges = form.getTextAreaByName("edges");
		textAreaEdges.setText("1 2\n");
		assertEquals("1 2\n", textAreaEdges.getText());
		
		    
		final HtmlTextInput textFieldEndNodes = form.getInputByName("endNode");
		textFieldEndNodes.setValueAttribute("2");
		assertEquals("2", textFieldEndNodes.getValueAttribute());
		
		final HtmlTextInput textFieldInitialNodes = form.getInputByName("initialNode");
		textFieldInitialNodes.setValueAttribute("1");
		assertEquals("1", textFieldInitialNodes.getValueAttribute());
		    
		try {
			page = buttonNodes.click();
		} catch (IOException e) {
			// TODO Auto-generated catch block
		e.printStackTrace();
		}

		assertEquals("1 2\n", page.getFormByName("graphCoverageForm").getTextAreaByName("edges").getText());
		final HtmlTable table = page.getHtmlElementById("tableResult");
		System.out.println(table.getCellAt(0, 0).asText());
		assertNotNull(((HtmlTable) page.getHtmlElementById("tableResult")).getCellAt(0, 0).asText());
		assertEquals( true, (((HtmlTable) page.getHtmlElementById("tableResult")).getCellAt(0, 0).asText() != null));
		
		try {
			page = buttonDataFlowCoverage.click();
		} catch (IOException e) {
			// TODO Auto-generated catch block
		e.printStackTrace();
		}
		
		assertEquals("dataFlowCoverageForm", page.getFormByName("dataFlowCoverageForm").getNameAttribute());
		
	    /*	  
	    textFieldInitialNodes = pageNodes.getFormByName("graphCoverageForm").getInputByName("initialNode");
	    assertEquals("1", textFieldInitialNodes.getValueAttribute());
	    
	    for (final HtmlTableRow row : table.getRows()) {
	        System.out.println("Found row");
	        for (final HtmlTableCell cell : row.getCells()) {
	            System.out.println("   Found cell: " + cell.asText());
	        }
	    }*/
	}
	@Test
	public void test1(){
		//initialize
		final WebClient webClient = new WebClient();
		WebRequest request = null;
		try {
		    request = new WebRequest( new URL("http://localhost:8080/CoverageWebApplication/coverage/GraphCoverage"), HttpMethod.POST);
		} catch (MalformedURLException e) {
		e.printStackTrace();
		}
				 
		HtmlPage page = null;
		try {
		    page = webClient.getPage(request);
		} catch (FailingHttpStatusCodeException e) {
		e.printStackTrace();
		} catch (IOException e) {
		e.printStackTrace();
		}
				
		HtmlForm form = page.getFormByName("graphCoverageForm");
				 
		final HtmlSubmitInput buttonNodes = form.getInputByValue("Nodes");
				
		final HtmlSubmitInput buttonEdges = form.getInputByValue("Edges");
				
		final HtmlSubmitInput buttonEdgePairs = form.getInputByValue("Edge-Pair");
				
		final HtmlSubmitInput buttonSimplePaths = form.getInputByValue("Simple Paths");
				
		final HtmlSubmitInput buttonPrimePaths = form.getInputByValue("Prime Paths");
					
		final HtmlSubmitInput buttonNodeCoverage = form.getInputByValue("Node Coverage");
				
		final HtmlSubmitInput buttonEdgeCoverage = form.getInputByValue("Edge Coverage");
				
		final HtmlSubmitInput buttonEdgePairCoverage = form.getInputByValue("Edge-Pair Coverage");
				
		final HtmlSubmitInput buttonPrimePathCoverage = form.getInputByValue("Prime Path Coverage");
				
		final HtmlSubmitInput buttonNewGraph = form.getInputByValue("New Graph");
				
		final HtmlSubmitInput buttonDataFlowCoverage = form.getInputByValue("Data Flow Coverage");
		final HtmlSubmitInput buttonLogicCoverage = form.getInputByValue("Logic Coverage");
		final HtmlSubmitInput buttonMinimalMUMCUTCoverage = form.getInputByValue("Minimal-MUMCUT Coverage");
				
		final HtmlTextArea textAreaEdges = form.getTextAreaByName("edges");
		final HtmlTextInput textFieldEndNodes = form.getInputByName("endNode");
		final HtmlTextInput textFieldInitialNodes = form.getInputByName("initialNode");
				
		final HtmlTable table = null;
		
		//enterGraph
		textAreaEdges.setText("1 2\n");	
		textFieldEndNodes.setValueAttribute("2");
		textFieldInitialNodes.setValueAttribute("1");
		
		//updateGraph
		textAreaEdges.setText("1 2\n1 3\n");	
		textFieldEndNodes.setValueAttribute("2 3");
		textFieldInitialNodes.setValueAttribute("1");
		
		//newGraph
		try {
			page = buttonNewGraph.click();
		} catch (IOException e) {
		e.printStackTrace();
		}
		
		//dataFlow
		try {
			page = buttonDataFlowCoverage.click();
		} catch (IOException e) {
		e.printStackTrace();
		}
		
		//logic
		try {
			page = buttonLogicCoverage.click();
		} catch (IOException e) {
		e.printStackTrace();
		}
		
		//minimalMUMCUT
		try {
			page = buttonMinimalMUMCUTCoverage.click();
		} catch (IOException e) {
		e.printStackTrace();
		}
		
		//edge
		try {
			page = buttonEdges.click();
		} catch (IOException e) {
		e.printStackTrace();
		}
		
		//node
		try {
			page = buttonNodes.click();
		} catch (IOException e) {
		e.printStackTrace();
		}
		
		//edgePair
		try {
			page = buttonEdgePairs.click();
		} catch (IOException e) {
		e.printStackTrace();
		}
		
		//simplePath
		try {
			page = buttonSimplePaths.click();
		} catch (IOException e) {
		e.printStackTrace();
		}
		
		//primePath
		try {
			page = buttonPrimePaths.click();
		} catch (IOException e) {
		e.printStackTrace();
		}
		
		//edgeCoverage
		try {
			page = buttonEdgeCoverage.click();
		} catch (IOException e) {
		e.printStackTrace();
		}
		
		//nodeCoverage
		try {
			page = buttonNodeCoverage.click();
		} catch (IOException e) {
		e.printStackTrace();
		}
		
		//primePathCoverage
		try {
			page = buttonPrimePathCoverage.click();
		} catch (IOException e) {
		e.printStackTrace();
		}
		
		//edgePairCoverage
		try {
			page = buttonEdgePairCoverage.click();
		} catch (IOException e) {
		e.printStackTrace();
		}
		
		//ConstraintResultNotNull
		assertTrue((((HtmlTable) page.getHtmlElementById("tableResult")).getCellAt(0, 0).asText() != null));
	} 

}
