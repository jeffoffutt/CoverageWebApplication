/**
 * 
 */
package coverage.graph;

/**
 * @author Wuzhi Xu, Date: Jan 5, 2007
 *
 */
public class InvalidGraphException extends Exception {

	/**
	 * 
	 */
	public InvalidGraphException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public InvalidGraphException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	public InvalidGraphException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 * @param arg1
	 */
	public InvalidGraphException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}
